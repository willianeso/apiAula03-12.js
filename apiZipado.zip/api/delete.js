// Importa a biblioteca axios que facilita as requisições HTTP
const axios =  require('axios');

// URL da API onde vamos atualizar os dados
const url = "https://jsonplaceholder.typicode.com/posts/1"

// Requisição DELETE
axios.delete(url)
    .then(response => {
        console.log("Recurso deletado com sucesso")
        console.log(`Status da resposta: ${response.status}`)
    })
    .catch(error =>{
        console.error(`Erro ao tentar deletar o recurso: ${error}`)
    })