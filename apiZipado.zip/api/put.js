// Importa a biblioteca axios que facilita as requisições HTTP
const axios =  require('axios');

// URL da API onde vamos atualizar os dados
const url = "https://jsonplaceholder.typicode.com/posts/1";

// Dados que queremos enviar para API (atualizando o POST com ID 1)
const dadosAtualizados = {
    title: "Título atualizado com PUT",
    body: "Exemplo de uma requisição put",
    userId: 1
}

// Fazendo requisição para atualizar o recurso na API
axios.put(url, dadosAtualizados)
    .then(response => {
        console.log("recurso atualizado com sucesso");
        console.log(response.data)
    })

    .catch(error => {
        console.error(`erro ao tentar atualizar o recurso: ${error}`)
    })